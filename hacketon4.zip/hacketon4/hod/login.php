<?php
session_start();
include('../db.php');

// Redirect if already logged in
if (isset($_SESSION['hod_id'])) {
    header("Location: dashboard.php");
    exit();
}

// Process login
if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM hods WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['hod_id'] = $user['id'];
        $_SESSION['hod_name'] = $user['name'];
        header("Location: dashboard.php");
        exit();
    } else {
        $login_error = "Invalid email or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOD Login | Leave Management System</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <!-- Custom CSS -->
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #f8f9fc;
        }
        
        body {
            font-family: 'Nunito', sans-serif;
            background-color: #f8f9fc;
            height: 100vh;
            display: flex;
            align-items: center;
        }
        
        .login-container {
            max-width: 500px;
            width: 100%;
            margin: 0 auto;
            padding: 2rem;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .login-header img {
            height: 80px;
            margin-bottom: 1rem;
        }
        
        .login-header h2 {
            color: var(--primary-color);
            font-weight: 700;
        }
        
        .form-control {
            padding: 0.75rem 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1.5rem;
            border: 1px solid #d1d3e2;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.25);
        }
        
        .btn-login {
            background-color: var(--primary-color);
            border: none;
            padding: 0.75rem;
            font-weight: 600;
            width: 100%;
            border-radius: 0.5rem;
            transition: all 0.3s;
        }
        
        .btn-login:hover {
            background-color: #2e59d9;
            transform: translateY(-2px);
        }
        
        .login-footer {
            text-align: center;
            margin-top: 1.5rem;
            color: #858796;
        }
        
        .login-footer a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
        }
        
        .login-footer a:hover {
            text-decoration: underline;
        }
        
        .error-message {
            color: #e74a3b;
            font-size: 0.9rem;
            margin-top: -1rem;
            margin-bottom: 1rem;
            text-align: center;
        }
        
        .input-group-text {
            background-color: #f8f9fc;
            border-right: none;
        }
        
        .input-with-icon {
            border-left: none;
        }
    </style>
</head>
<body>
    <div class="container animate__animated animate__fadeIn">
        <div class="login-container">
            <div class="login-header">
                <svg width="400" height="100" xmlns="http://www.w3.org/2000/svg">
    <g fill="none" stroke="none" stroke-width="1">
        <!-- Leaf Icon -->
        <path d="M20,50 C25,30, 45,35, 40,20 C55,35, 55,70, 30,60 C10,55, 5,40, 20,50 Z" fill="#FF6F61" />
        
        <!-- Text -->
        <text x="60" y="60" font-family="Arial" font-size="48" fill="#253D68">Equi</text>
        <text x="160" y="60" font-family="Arial" font-size="48" fill="#F07C91">Leave</text>
    </g>
</svg>
                <h2 class="animate__animated animate__fadeInDown">HOD Login</h2>
                <p class="text-muted animate__animated animate__fadeIn animate__delay-1s">Enter your credentials to access the dashboard</p>
            </div>
            
            <?php if (isset($login_error)): ?>
                <div class="alert alert-danger animate__animated animate__shakeX" role="alert">
                    <?php echo $login_error; ?>
                </div>
            <?php endif; ?>
            
            <form action="" method="POST">
                <div class="mb-3">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                        <input type="email" name="email" class="form-control input-with-icon" placeholder="Email address" required>
                    </div>
                </div>
                
                <div class="mb-4">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" name="password" class="form-control input-with-icon" placeholder="Password" required>
                    </div>
                </div>
                
                <div class="d-grid mb-3">
                    <button type="submit" name="login" class="btn btn-primary btn-login animate__animated animate__pulse animate__delay-2s">
                        <i class="fas fa-sign-in-alt me-2"></i> Login
                    </button>
                </div>
                
                <div style="text-align:right; margin-top: 10px;">
    <a href="../forgot_password.php" style="text-decoration: none; color: #007bff;">Forgot Password?</a>
</div>

            </form>
            
            <div class="login-footer">
                <p>&copy; <?php echo date('Y'); ?> Leave Management System. All rights reserved.</p>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script>
        // Add animation to form elements
        document.addEventListener('DOMContentLoaded', function() {
            const inputs = document.querySelectorAll('.form-control');
            inputs.forEach((input, index) => {
                input.classList.add('animate__animated', 'animate__fadeInUp');
                input.style.animationDelay = `${0.1 * index}s`;
            });
        });
    </script>
</body>
</html>