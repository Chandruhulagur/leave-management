<?php
session_start();
include('../db.php');

if (!isset($_SESSION['hod_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch all leave applications
$sql = "SELECT la.*, s.name AS student_name 
        FROM leave_applications la 
        JOIN students s ON la.student_id = s.id 
        ORDER BY la.applied_on DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Leave History - HOD</title>
    <link rel="stylesheet" href="../assets/css/form-style.css">
    <style>
        body {
            background: #f4f6f9;
            font-family: 'Segoe UI', sans-serif;
        }

        .container {
            max-width: 1000px;
            margin: auto;
            padding: 30px;
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            border-radius: 8px;
        }

        th, td {
            padding: 12px 14px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        th {
            background-color: #f7f7f7;
        }

        .status {
            padding: 5px 10px;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            font-size: 14px;
        }

        .Approved {
            background-color: #28a745;
        }

        .Rejected {
            background-color: #dc3545;
        }

        .Pending {
            background-color: #ffc107;
            color: #000;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #007bff;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Leave Application History</h2>

    <?php if ($result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Leave Type</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Reason</th>
                    <th>Status</th>
                    <th>Applied On</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($leave = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($leave['student_name']) ?></td>
                        <td><?= htmlspecialchars($leave['leave_type']) ?></td>
                        <td><?= htmlspecialchars($leave['from_date']) ?></td>
                        <td><?= htmlspecialchars($leave['to_date']) ?></td>
                        <td><?= htmlspecialchars($leave['reason']) ?></td>
                        <td>
                            <span class="status <?= $leave['status'] ?>">
                                <?= $leave['status'] ?>
                            </span>
                        </td>
                        <td><?= date('d M Y', strtotime($leave['applied_on'])) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No leave applications found.</p>
    <?php endif; ?>

    <a class="back-link" href="dashboard.php">← Back to Dashboard</a>
</div>

</body>
</html>
