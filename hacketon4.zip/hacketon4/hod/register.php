<?php include('../db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOD Registration | University Leave System</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #1a252f;
            --light-bg: #f8f9fa;
            --dark-text: #2c3e50;
            --success-color: #27ae60;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-bg);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.9), rgba(255, 255, 255, 0.9)),
                url('https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
        }
        
        .registration-container {
            max-width: 500px;
            width: 100%;
            padding: 2.5rem;
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .registration-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .registration-header img {
            height: 80px;
            margin-bottom: 1rem;
        }
        
        .registration-header h2 {
            color: var(--dark-text);
            font-weight: 700;
        }
        
        .form-control {
            padding: 0.75rem 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1.5rem;
            border: 1px solid #d1d3e2;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(44, 62, 80, 0.25);
        }
        
        .btn-register {
            background-color: var(--success-color);
            border: none;
            padding: 0.75rem;
            font-weight: 600;
            width: 100%;
            border-radius: 0.5rem;
            transition: all 0.3s;
        }
        
        .btn-register:hover {
            background-color: #219653;
            transform: translateY(-2px);
        }
        
        .registration-footer {
            text-align: center;
            margin-top: 1.5rem;
            color: #6c757d;
        }
        
        .registration-footer a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
        }
        
        .registration-footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="registration-container">
        <div class="registration-header">
              <svg width="400" height="100" xmlns="http://www.w3.org/2000/svg">
    <g fill="none" stroke="none" stroke-width="1">
        <!-- Leaf Icon -->
        <path d="M20,50 C25,30, 45,35, 40,20 C55,35, 55,70, 30,60 C10,55, 5,40, 20,50 Z" fill="#FF6F61" />
        
        <!-- Text -->
        <text x="60" y="60" font-family="Arial" font-size="48" fill="#253D68">Equi</text>
        <text x="160" y="60" font-family="Arial" font-size="48" fill="#F07C91">Leave</text>
    </g>
</svg>
            <h2>HOD Registration</h2>
            <p class="text-muted">Register as Department Head</p>
        </div>
        
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                HOD Registered successfully!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                Error: <?php echo htmlspecialchars($_GET['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <form action="" method="POST">
            <div class="mb-3">
                <input type="text" name="name" class="form-control" placeholder="Full Name" required>
            </div>
            
            <div class="mb-3">
                <input type="email" name="email" class="form-control" placeholder="University Email" required>
            </div>
            
            <div class="mb-3">
                <input type="password" name="password" class="form-control" placeholder="Create Password" required>
            </div>
            
            <div class="d-grid mb-3">
                <button type="submit" name="register" class="btn btn-register">
                    <i class="fas fa-user-plus me-2"></i> Register
                </button>
            </div>
            
            <div class="registration-footer">
                <p>Already have an account? <a href="login.php">Login here</a></p>
                <p class="mt-2"><a href="../index.php"><i class="fas fa-arrow-left me-1"></i> Back to Home</a></p>
            </div>
        </form>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
if (isset($_POST['register'])) {
    $name     = $_POST['name'];
    $email    = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO hods (name, email, password) VALUES ('$name', '$email', '$password')";
    if ($conn->query($sql)) {
        header("Location: register.php?success=1");
        exit();
    } else {
        header("Location: register.php?error=" . urlencode($conn->error));
        exit();
    }
}
?>